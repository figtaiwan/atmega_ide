define(function() {
  return {
 
 initialize: function(app) {
  	//app.sandbox.autodict=autodict;
  	console.log('Autodict started')
  },
  loaddictionary:function() {f

  },
  afterAppStart: function() {
  }
}});